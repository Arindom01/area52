class taskProcessor:

  def __init__(self):
    return

  def process(self, action_payload):

    return action_payload
