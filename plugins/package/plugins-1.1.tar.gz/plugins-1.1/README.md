# area52
CICD Archetype generator

## Background:

This repository consists of a lightweight reusable framework which can generate complete cicd ready archetype projects for consumption of developers. The framework nicely wraps the utilities in cli calls and makes it available for use. It heavily uses Jinja2 templating package to bind parameters and generate a shell project which can be treated as a starting point for any project which has all cicd codes baked into the project.

## How it works:

The template projects are added with a special templating notation {{cookiecutter.project_slug}}. This is actually a project directory placeholder to be created when an actual project name is provided. This directory should have all templates and resources required for the project harness. All the variables uses everywhere in the project harness with a notation {{cookiecutter.*****}} binds with cookiecutter.json file. This is a master file which holds all information passed by the user to generate a new project. Once the actual project is generated from the template project, other plugins like gitsetup or jenkinssetup are being invoked by the CD process to add additional toppings to the project like creating a github repository in the organization requested or giveing a PR with the initial archetype project.

## Features 

1. Create projects archetype/harness with all CICD packages pre-baked (currently only support Python lambda and StepFunction)
2. Setup a GitHub repo with a initial PR that consusts of the generated code
3. Generates dummy test and coverage run in the pipeline
3. Setup al the githooks to CI
4. Setup the Jenkins Pipeline associated with it.
5. Projects are pre-prod ready and can be deployed without any changes
6. Heavyly uses Pyhon Jinja2 templating, cookicutter for Project generation, GitHub API for integration.
7. A plugin based framework which can be extended in future with minimal changes. If another project type (SpringBoot - Java) needs to have an archetype , it can be done easily bu adding a plugin or two.


## Local Installation:

| Step#         |   Details     |
| ------------- |:--------------|
|Step1:| git clone https://github.td.teradata.com/as250169/area52.git |
|Step2:| cd area52|
|Step3:| virtualenv venv|
|Step4:| source venv/bin/activate|
|Step5:| pip install -r requirements.txt|
|Step6:| python setup.py install|



## Usage:

### to find available commands run 
area52 --help

### to bind all environment variables to a cookiecutter.json template
area52 bindparams --filepath cookiecutter.json

### to generate the project from the template
area52 cookiecutter --template_path .

### to setup the github ci
area52 gitsetup --commit_dir '<<project_name>>'

